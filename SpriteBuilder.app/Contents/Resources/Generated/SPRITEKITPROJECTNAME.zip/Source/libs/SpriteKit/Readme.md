SpriteBuilder: Sprite Kit Support Project
----

Contains:

- symlink to cocos2d-iphone CCBReader files
- CCBReader extension classes for Sprite Kit compatibility
- Sprite Kit extension classes (Kobold Kit) to add cocos2d-iphone and other features

