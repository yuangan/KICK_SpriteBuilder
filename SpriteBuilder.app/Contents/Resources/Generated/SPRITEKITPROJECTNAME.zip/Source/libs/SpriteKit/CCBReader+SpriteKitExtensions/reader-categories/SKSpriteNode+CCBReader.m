//
//  SKSpriteNode+CCBReader.m
//  SpriteKitReader-Experimental
//
//  Created by Steffen Itterheim on 16/01/14.
//  Copyright (c) 2014 Steffen Itterheim. All rights reserved.
//

#import "SKSpriteNode+CCBReader.h"
#import "CCBSpriteKitCompatibility.h"

@implementation SKSpriteNode (CCBReader)

@end
